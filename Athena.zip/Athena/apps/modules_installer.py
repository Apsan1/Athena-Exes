"""
    This script is used to install all the required modules for the voice assistant to work.
"""
import subprocess
def install_module(module_name):
    try:
        subprocess.check_call(['pip', 'install', module_name])
        print(f"Successfully installed {module_name}")
    except subprocess.CalledProcessError:
        print(f"Failed to install {module_name}")

# Example usage
install_module("requests")
install_module("tk")
install_module("speechrecognition")
install_module("pyttsx3")
install_module("pyaudio")
install_module("datetime")
install_module("openai")
install_module("pyjokes")
install_module("pyperclip")
install_module("icalendar")
install_module("pathlib")
install_module("PyQt5")

print("All modules installed successfully")