"""
    This is the main file of the project. It contains all the functions and the main loop of the program.
    This is the file that needs to be run to start the voice assistant.
    This is where you can add your own commands and responses if you want and develop more but 
    do not forget to at least give me some credit for the base code and the idea to develop this project.
"""
import speech_recognition as sr
import pyttsx3
import webbrowser
import requests
import random
import subprocess
import datetime
from datetime import date
import openai
import os
import time
import json
import pyjokes
import imaplib
from queue import Queue
import pyperclip
import sys
import threading
from icalendar import Calendar, Event
from datetime import date, timedelta
import json

# Initialize the speech recognition and text-to-speech engines
recognizer = sr.Recognizer()
engine = pyttsx3.init()


def speak(text):
    '''
        Speaks the text passed to it
    '''
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)  # This is a female voice
    engine.setProperty('rate', 145)  # Adjust the rate as needed
    engine.say(text)
    engine.runAndWait()


def user_data_extract():
    '''
        This function is used to extract the user data from the JSON file.
        It returns the user data as a dictionary.
    '''
    try:
        with open(r'data\user_data.json', 'r') as file:
            user_data = json.load(file)
            return user_data
    except FileNotFoundError:
        return {}


def extract_data():
    '''
    This function uses the extracted user data and assigns it to the variables.
    '''
    user_data = user_data_extract()
    user_name = user_data.get('user_name', '')
    openai_api_key = user_data.get('openai_api_key', '')
    openweather_api_key = user_data.get('openweather_api_key', '')
    personal_mail = user_data.get('personal_mail', '')
    personal_mail_pw = user_data.get('personal_mail_pw', '')
    secondary_mail = user_data.get('secondary_mail', '')
    secondary_mail_pw = user_data.get('secondary_mail_pw', '')
    calendar_link = user_data.get('calendar_link', '')
    return user_name, openai_api_key, openweather_api_key, personal_mail, personal_mail_pw, secondary_mail, secondary_mail_pw, calendar_link


user_name, openai_api_key, openweather_api_key, personal_mail, personal_mail_pw, secondary_mail, secondary_mail_pw, calendar_link = extract_data()

openai.api_key = openai_api_key  # OpenAI API key

offline_mode = False  # Offline mode is used to run the program without internet connection
output_queue = None  # This is the queue used to store the output of the program
maxormin = None  # This is used to store the max or min size of screen


awake_quotes = ["Was a great nap!, How can I help?", "What's up?", "Help Here", "How are things?", "How's your day going?", "How's your day?", "How are you doing?",
                "How are you?", "What's happening?", "What's going on?", "What's new?", "What's the good word?", "Rise and shine! Time to wake up and embrace the day. Remember, life's too short to sleep through all the fun!"
                ]

greeting_quotes = ["Hi", "Hello", "Namaste",
                   "Nahmaskar", "Darśshan Huhjur lai", "Konichiwa"]

help_quotes = ["I am here to help you", "I am here to assist you", "I am here to help you out", "I am here to assist you out",
               "I am here to help you with your tasks", "I am here to assist you with your tasks",
               "I can give you company"]

bye_quotes = ['See you soon', 'shutting down', 'bye bye',
              'see you later', 'see you soon', 'have a nice day', 'enjoy your time']

gg_quotes = ['Happy Gaming', 'Enjoy your game',
             "Every game is an opportunity to level up and become a better player.",
             "In the game of life, play with passion, perseverance, and a hunger for success.",
             "The true joy of gaming lies not only in winning but in the journey and the challenges it brings.",
             "Game on! Embrace the thrill of competition and strive to be the best.",
             "Remember, it's not about how many times you fall in the game, but how many times you get back up and keep playing.",
             "In gaming and in life, every setback is an opportunity for a comeback.",
             "A game is not just about pixels and controllers; it's a chance to explore new worlds and create unforgettable memories.",
             "The best players don't just play the game; they immerse themselves in it and leave a mark.",
             "In the game of success, the only limit is the one you set for yourself.",
             "Mastering a game takes time, practice, and a willingness to learn from both victories and defeats.",
             "Play with sportsmanship, respect, and a spirit of camaraderie. It's not just about winning; it's about the experience.",
             "The beauty of gaming lies in the connections we make, the friendships we forge, and the shared experiences we cherish.",
             "Don't be afraid to take risks, try new strategies, and push beyond your comfort zone. Greatness comes from daring to be different.",
             "Remember, it's not just about the final score; it's about the memories, the laughter, and the friendships formed along the way.",
             "In the game of life, the true winners are those who find joy in every moment and inspire others to do the same.",
             "When the game gets tough, stay focused, stay determined, and believe in your ability to overcome any challenge.",
             "Gaming is not just a hobby; it's an art form that allows us to unleash our creativity and imagination.",
             "Celebrate every achievement, no matter how small. Each milestone is a testament to your growth and progress.",
             "The game may change, but the passion and love for gaming remain constant.",
             "Embrace the game of life with a childlike wonder, curiosity, and a thirst for adventure.",
             "In the game of success, there are no shortcuts. It's the dedication, hard work, and perseverance that lead to victory.",
             ]

good_morning_quotes = ['Good Morning', 'Good Morning, Captain boat is ready', 'Good Morning, Sir', 'System online and ready to serve you',
                       "Rise and shine! It's a brand new day filled with endless possibilities.",
                       "Sending you a big smile and lots of love to start your day off right. Good morning!",
                       "Wake up with determination, go to bed with satisfaction. Have a fantastic morning!",
                       "Every morning is a chance at a new beginning. Embrace it with open arms and a grateful heart.",
                       "May your morning be as bright and beautiful as your smile. Good morning!",
                       "Today is a gift. Don't forget to unwrap it and make the most of every moment. Good morning!",
                       "Wishing you a day filled with laughter, joy, and all the goodness life has to offer. Good morning!",
                       "Good morning! May your day be filled with positivity, kindness, and success in all your endeavors.",
                       "Rise above the challenges, seize the opportunities, and make today the best day of your life. Good morning!",
                       "Here's to a morning filled with happy thoughts, warm hugs, and a cup of your favorite coffee. Enjoy!",
                       "Waking up is like being reborn every day, except instead of a delivery room, you have a cozy bed, and instead of crying, you can start the day with laughter and a cup of coffee! haha good morning!"
                       ]

good_afternoon_quotes = [
    "Good afternoon! May the rest of your day be as beautiful as the morning was.",
    "Wishing you a delightful afternoon filled with happiness and success.",
    "Take a break, breathe in the fresh air, and enjoy the beauty of this afternoon.",
    "Sending you warm wishes for a peaceful and productive afternoon. Make it count!",
    "Good afternoon! May your afternoon be filled with pleasant surprises and wonderful moments.",
    "Take a moment to pause and appreciate the beauty of this afternoon. Enjoy every moment.",
    "May your afternoon be filled with sunshine, laughter, and sweet moments to cherish.",
    "Sending you positive vibes and energy to carry you through the afternoon.",
    "Good afternoon! Remember to take some time for yourself and recharge.",
    "Wishing you a lovely afternoon filled with love, joy, and good company.",
    "Embrace the beauty of this afternoon and let it inspire you to accomplish great things.",
    "As the sun shines brightly, may your afternoon be filled with positivity and success.",
    "Take a deep breath and let go of any stress. It's time to enjoy a peaceful afternoon.",
    "Good afternoon! May your day continue to unfold with endless possibilities and happiness.",
    "Wishing you a vibrant and productive afternoon. Keep shining!",
    "Pause for a moment and appreciate the beauty of this afternoon. Life is filled with wonders.",
    "Sending you warm afternoon wishes filled with love, peace, and contentment.",
    "May the afternoon bring you closer to your goals and dreams. Keep pushing forward.",
    "Good afternoon! Let go of what didn't go right in the morning and embrace the possibilities of the afternoon.",
    "Take a short break, enjoy a cup of tea, and recharge yourself for the rest of the day.",
    "Sending you rays of positivity and motivation to make this afternoon a successful one.",
    "Good afternoon! May your afternoon be filled with laughter, good conversations, and memorable moments.",
    "Wishing you a peaceful afternoon where all your worries and stress fade away.",
    "As the day progresses, may your energy and enthusiasm for life remain high. Have a fantastic afternoon!"
]

cheer_up_quotes = [
    "Cheer up! You're stronger than you think you are.",
    "Don't let a bad day make you feel like you have a bad life.",
    "No matter how you feel, get up, dress up, show up, and never give up.",
    "When life knocks you down, roll over and look at the stars.",
    "You are stronger than you think. You have gotten through every bad day in your life, and you are undefeated.",
    "When life gives you a hundred reasons to cry, show life that you have a thousand reasons to smile.",
    "When life gives you lemons, make lemonade.",
    "When life gives you a hundred reasons to break down and cry, show life that you have a million reasons to smile and laugh."
    "You are capable of amazing things.",
    "The only way to do great work is to love what you do.",
    "You are not alone. You are loved and supported.",
    "Believe in yourself, and all that you are. Know that there is something inside you that is greater than any obstacle.",
    "Every day may not be good, but there is something good in every day.",
    "Keep going. You're making progress, even if it doesn't seem like it.",
    "Success is not final, failure is not fatal: It is the courage to continue that counts.",
    "Your present circumstances don't determine where you can go, they merely determine where you start.",
    "Focus on the positive. The more you celebrate life, the more there is in life to celebrate.",
    "You are unique and have something special to offer the world.",
    "Don't be afraid to ask for help. Sometimes a fresh perspective is all you need.",
    "You have the power to create the life you want. Take small steps every day towards your goals.",
    "Remember why you started. Stay focused, and keep pushing forward.",
    "Even the darkest night will end and the sun will rise.",
    "Believe in the beauty of your dreams and the strength of your abilities.",
    "You are not defined by your past. Your future is what matters.",
    "The world needs your light. Shine brightly and inspire others.",
    "Keep your head up. God gives his hardest battles to his strongest soldiers.",
    "You are stronger than your challenges. Keep fighting, and never give up.",
    "Every setback is a setup for a comeback. Believe in yourself and keep moving forward.",
    "The sun will rise and we will try again.",
    "Tough times don't last, but tough people do.",
    "Every cloud has a silver lining.",
    "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle.",
    "In the middle of every difficulty lies opportunity.",
    "You've got this. Keep going!",
    "The best way to predict the future is to create it.",
    "Keep your face to the sunshine and you cannot see a shadow.",
    "It's just a bad day, not a bad life.",
    "Remember, you are one step closer with every setback.",
    "Difficult roads often lead to beautiful destinations.",
    "You are braver than you believe, stronger than you seem, and smarter than you think."
]

good_evening_quotes = [
    "Good evening! May the setting sun take down all your sufferings with it and make you hopeful for a new day.",
    "Good evening! May this beautiful evening fill your heart with hope and happiness.",
    "May the setting sun take away all your worries and concerns and fill your evening with joy and contentment.",
    "Good evening! Wishing you a relaxing and peaceful evening ahead.",
    "As the day comes to a close, may your evening be filled with joy and contentment.",
    "Sending you warm wishes for a beautiful and pleasant evening.",
    "May your evening be as lovely as the sunset and as peaceful as the moonlit night.",
    "Good evening! Take a moment to appreciate the beauty of this evening and count your blessings.",
    "Wishing you a delightful evening filled with laughter, good company, and beautiful moments.",
    "Embrace the serenity of this evening and let it rejuvenate your mind, body, and soul.",
    "May your evening be filled with happiness, love, and cherished memories.",
    "Sending you positive vibes and good energy for a fantastic evening ahead.",
    "Good evening! Remember to take some time for yourself and do something that brings you joy.",
    "As the day bids farewell, may your evening be filled with peace and tranquility.",
    "Wishing you a calm and refreshing evening that sets the stage for a peaceful night's rest.",
    "Enjoy the little moments of this evening and create beautiful memories to cherish.",
    "Good evening! May the stars shine brightly on your path and guide you to success.",
    "Take a deep breath and let go of any worries. It's time to relax and unwind in the evening.",
    "Wishing you a serene evening where you can unwind and find solace in the stillness.",
    "May your evening be a perfect blend of relaxation, joy, and fulfillment.",
    "Good evening! Reflect on the blessings of the day and look forward to a brighter tomorrow.",
    "Take a stroll, watch the sunset, and let the beauty of the evening inspire you.",
    "Sending you warm hugs and positive thoughts for a cozy and peaceful evening.",
    "Wishing you an evening filled with pleasant surprises and delightful moments.",
    "Good evening! May your evening be as wonderful as your smile.",
    "As the day draws to a close, may your evening be filled with gratitude and inner peace.",
    "Take a break from the busyness of life and enjoy a tranquil evening of relaxation.",
    "Sending you good vibes and blessings for a beautiful and memorable evening.",
    "Good evening! May your evening be filled with laughter, love, and happiness."
]

good_night_quotes = [

    "Goodnight! Rest your mind, body, and soul, and wake up refreshed to conquer the world.",
    "As you lay down to sleep, remember that tomorrow holds new opportunities and endless possibilities. Goodnight!",
    "Wishing you a peaceful and restful night's sleep. May you wake up with renewed energy and determination.",
    "Goodnight! Believe in yourself and your dreams. Tomorrow is another chance to make them a reality.",
    "May your dreams be filled with inspiration and your sleep be deep and restful. Goodnight!",
    "As the day ends, take a moment to appreciate how far you've come. Rest well and dream big. Goodnight!",
    "Close your eyes and imagine a brighter future. Sleep tight and wake up ready to make it a reality. Goodnight!",
    "Wishing you a night filled with dreams that ignite your passion and fuel your drive. Goodnight!",
    "Even the longest journeys start with a single step. Rest well tonight and prepare for a new day of progress. Goodnight!",
    "As you sleep, let go of any doubts or fears. Embrace the power within you and wake up ready to achieve greatness. Goodnight!",
    "Goodnight! Remember that every night is a chance to recharge and wake up with a fresh perspective.",
    "As the stars twinkle above, know that you are capable of shining just as brightly. Sleep well and dream big. Goodnight!",
    "Wishing you a peaceful night's sleep filled with dreams that inspire and motivate you. Goodnight!",
    "Goodnight! Rest your body, but never let your dreams rest. Chase them with passion and determination.",
    "As you drift off to sleep, remember that tomorrow is a blank canvas waiting for your masterpiece. Goodnight!",
    "Close your eyes, relax your mind, and visualize the success that awaits you. Sleep tight and dream big. Goodnight!",
    "May your dreams be filled with visions of success, happiness, and fulfillment. Goodnight!",
    "Goodnight! Tomorrow is a new day, a fresh start, and another opportunity to make your dreams come true.",
    "Rest well tonight, for tomorrow you will rise and continue your journey towards greatness. Goodnight!",
    "As the night envelops you, let go of the challenges of today and embrace the promises of tomorrow. Goodnight!",
    "Wishing you a night filled with peace, clarity, and the motivation to chase your dreams. Goodnight!"
]

howareyou_quotes = ['I am excited to help you out', 'I am excited to help you', 'I am excited to assist you', 'I am excited to assist you out', 'I am excited to help you with your tasks', 'I am excited to assist you with your tasks',
                    'I am doing great. I am excited to help you out', 'I am doing great. I am excited to help you', 'I am doing great. I am excited to assist you', 'I am doing great. I am excited to assist you out',
                    'I am doing great. I am excited to help you with your tasks', 'I am doing great. I am excited to assist you with your tasks', 'Lovely, I am ready for tasks today', 'Robotically, Fine. Wait I am always fine.',
                    'Not getting paid, joking haha']


def introduce():
    '''
        Introduces Athena to the user
    '''
    speak("I am Athena. I am still developing and for now, I am able to do some general tasks which could save your time and also motivate you. Feel free to ask me anything.")


def greeting():
    '''
        Greets the user
    '''
    random_greeting = random.choice(greeting_quotes)
    random_help = random.choice(help_quotes)
    speak(f"{random_greeting}, {random_help}.")


def handle_greeting(command):
    '''
        Handles the greeting of the user and responds accordingly
    '''
    if 'meet my' in command:
        greet = command.replace('meet my', '')
        speak(f"Hello {greet}, how are you?")
    elif 'say hi to my' in command:
        greet = command.replace('say hi to my ', '')
        speak(f"Hello {greet}, how are you?")


def explain_features():
    '''
        Explains the features of Athena
    '''
    feature = "I am Athena, your reliable assistant ready to assist you in various tasks. " \
            "I can provide you with the current time, date, and day, ensuring you stay organized and punctual. " \
            "If you need to find information quickly, I can perform web searches on Google, bringing you the answers you seek. " \
            "Whether you're in the mood for entertainment or seeking educational content, I can guide you through the vast world of YouTube. " \
            "Managing your emails is a breeze with me by your side, helping you stay on top of your inbox effortlessly. " \
            "Let me serenade you with your favorite tunes, as I can play music to keep you entertained and relaxed. " \
            "Stay informed about the ever-changing weather conditions by simply asking me for updates. Feeling bored? " \
            "I've got you covered with a repertoire of jokes to bring a smile to your face. When you need an extra boost of motivation, " \
            "I can share inspiring quotes to uplift your spirits. Need to remember important tasks? I can help you set reminders, " \
            "ensuring nothing slips through the cracks. Stay in the loop with any upcoming updates, as I will keep you informed. " \
            "Together, we'll navigate through your day and make it a smooth and productive journey."
    speak(feature)


def try_again():
    '''
        Asks the user if they want to try again
    '''
    try_again_audio = listen()
    try_again = recognizer.recognize_google(try_again_audio)
    if "yes" in try_again:
        return True
    else:
        speak("Okay")
        return False


def perform_search(query):
    '''
        Performs a google search for the query passed to it with the help of webbrowser module
        else tries chatgpt for the query
    '''
    query = query.replace("search", "")
    query = query.strip()
    if query:
        if "in browser" in query:
            query = query.replace("in browser", "")
            query = query.strip()
            search_url = f"https://www.google.com/search?q={query}"
            webbrowser.open(search_url)
        else:
            chatgpt_response()
    else:
        speak("Sorry, I couldn't understand your search query.")
        speak("Do you want me to try again?")
        again = try_again()
        if again:
            perform_search(listen())


def open_apps(command):
    '''
        Opens the apps in the system based on the command passed to it
        you can add more apps to the list
    '''
    speak("Searching for the app in your system")

    if "notepad" in command:
        speak("Here you go.")
        subprocess.Popen("C:\\Windows\\System32\\notepad.exe")
    elif "calculator" in command:
        speak("Here you go.")
        subprocess.Popen("C:\\Windows\\System32\\calc.exe")
    elif "paint" in command:
        speak("Here you go.")
        subprocess.Popen("C:\\Windows\\System32\\mspaint.exe")
    elif "word" in command:
        speak("Here you go.")
        subprocess.Popen(
            "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE")
    elif "powerpoint" in command:
        speak("Here you go.")
        subprocess.Popen(
            "C:\\Program Files\\Microsoft Office\\root\\Office16\\POWERPNT.EXE")
    elif "code" in command:
        speak("Here you go.")
        subprocess.Popen(
            "C:\\Users\\ASUS\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe")
    elif "browser" in command:
        speak("Here you go.")
        webbrowser.open("https://www.google.com")
    elif "no" in command:
        speak("Ok")
    else:
        speak(f"Sorry, I couldn't find any relevant results for it.")


def open_email():
    '''
        Opens the email based on the query passed to it
        you can add more emails to the list and to launch them you need to add the path of link properly
        mostly it will be https://mail.google.com/mail/u/0/#inbox or https://mail.google.com/mail/u/1/#inbox
        or similar to this.
    '''
    speak("Which mail? Personal or Secondary?")
    send_output_text("Which mail? Personal or Secondary?")
    mail_query_audio = listen()
    mail_query = recognizer.recognize_google(mail_query_audio)
    mail_query = mail_query.lower()
    send_output_text(mail_query)
    if "personal" in mail_query or "my" in mail_query or "mine" in mail_query or "myself" in mail_query or "me" in mail_query:
        speak("Opening Personal Gmail")
        webbrowser.open("https://mail.google.com/mail/")
    elif "secondary" in mail_query or "second" in mail_query or "college" in mail_query or "office" in mail_query or "work" in mail_query:
        speak("Opening Secondary Gmail")
        webbrowser.open("https://mail.google.com/mail/")
    elif "no" in mail_query or "close" in mail_query or "exit" in mail_query:
        speak("Okay")
    else:
        speak(
            f"Sorry, I couldn't find any relevant results for '{mail_query}'.")
        return open_email()


def open_movies():
    '''
        Opens the movies website
    '''
    speak("Opening Movies")
    url = "yts.mx"
    webbrowser.open(url)
    handle_command(listen())


def play_songs():
    '''
        Plays the songs based on the query passed to it
        you can add more songs to the list and to launch them you need to add the path of link properly
        mostly it will be https://www.youtube.com/results?search_query= or https://www.youtube.com/watch?v=
        or similar to this.
    '''

    speak("Which song?")
    song_query_audio = listen()
    song_query = recognizer.recognize_google(song_query_audio)
    song_query = song_query.lower()
    if "no" in song_query or "close" in song_query or "exit" in song_query:
        speak("Okay")
        handle_command(listen())
    elif "" in song_query:
        speak(
            "Sorry, I couldn't find any relevant results for '{song_query}'.")
        speak("Do you want me to try again?")
        again = try_again()
        if again == True:
            sites_open()
        else:
            speak("Okay")
    elif "on youtube" in song_query or "youtube" in song_query or "YouTube" in song_query:
        song_query = song_query.replace("on youtube", "")
        search_query = song_query + "song"  # Append "music" to the search query
        youtube_url = f"https://www.youtube.com/results?search_query={search_query}"
        webbrowser.open(youtube_url)

    # if you have spotify installed in your system then you can uncomment the below code and use it
    # elif "on spotify" in song_query or "spotify" in song_query:
        # subprocess.Popen("C:\\Users\\ASUS\\AppData\\Roaming\\Spotify\\Spotify.exe")

    else:
        search_query = song_query + "song"  # Append "music" to the search query
        youtube_url = f"https://www.youtube.com/results?search_query={search_query}"


def open_youtube():
    '''
        Opens the youtube website
    '''
    speak("Opening Youtube")
    webbrowser.open("https://www.youtube.com/")


def sites_open():
    '''
        Opens the sites based on the query passed to it
        you can add more sites to the list and to launch them you need to add the path of link properly
    '''
    speak("Which site would you like to open?")
    speak("Up for movies or songs or youtube?")
    site_query_audio = listen()
    site_query = recognizer.recognize_google(site_query_audio)
    site_query = site_query.lower()
    if "movies" in site_query:
        open_movies()
    elif "songs" in site_query or "song" in site_query or "music" in site_query:
        play_songs()
    elif "youtube" in site_query:
        open_youtube()
    elif "no" in site_query or "close" in site_query or "exit" in site_query:
        speak("Ok")

    else:
        speak(
            f"Sorry, I couldn't find any relevant results for '{site_query}'.")
        speak("Do you want me to try again?")
        again = try_again()
        if again == True:
            sites_open()
        else:
            speak("Ok")


def check_weather():
    '''
        Checks the weather of the city passed to it
        you can change name of cities or add more weather information to the list
    '''
    if openweather_api_key != "":
        speak("Weather of Kathmandu")
        city_name = "kathmandu"

        base_url = "http://api.openweathermap.org/data/2.5/weather"
        api_key = openweather_api_key

        params = {
            "q": city_name,
            "appid": api_key,
            # Specify the desired unit of measurement (metric, imperial, etc.)
            "units": "metric"
        }

        response = requests.get(base_url, params=params)
        weather_data = response.json()

        if weather_data["cod"] == 200:
            main = weather_data["main"]
            temperature = main["temp"]
            feels_like = main["feels_like"]
            humidity = main["humidity"]
            wind = weather_data["wind"]
            wind_speed = wind["speed"]
            weather = weather_data["weather"]
            weather_description = weather[0]["description"]
            weather_info = f"{city_name}\nTemperature: {temperature}°C\nFeels like: {feels_like}°C\nWeather: {weather_description}"
            send_output_text(weather_info)
            speak(f"The weather in {city_name} is {weather_description}. The temperature is {temperature} degrees Celsius, but it feels like {feels_like} degrees Celsius. The humidity is {humidity} percent and the wind speed is {wind_speed} kilometers per hour.")

    elif openweather_api_key == "":
        speak("You need to add your OpenWeather API key to use this feature.")

    else:
        speak("Sorry, I couldn't find any relevant results for '{city_name}'.")
        speak("Do you want me to try again?")
        again = try_again()
        if again == True:
            check_weather()
        else:
            speak("Okay")


def play_games():
    '''
        Plays the games based on the query passed to it
        you can add more games to the list and to launch them you need to add the path of link properly
    '''
    game_query_audio = listen()
    game_query = recognizer.recognize_google(game_query_audio)
    game_query = game_query.lower()
    if 'yes' in game_query or "start" in game_query or "open" in game_query or "play" in game_query or "yeah" in game_query or "sure" in game_query:
        speak("Opening Valorant")
        subprocess.Popen("C:\\Riot Games\\Riot Client\\RiotClientServices.exe")
        game_mode()
    elif 'no' in game_query or "close" in game_query or "exit" in game_query:
        speak("Okay")
        handle_command(listen())
    else:
        speak(
            f"Sorry, I couldn't find any relevant results for '{game_query}'.")
        speak("Do you want me to try again?")
        again = try_again()
        if again == True:
            return play_games()
        else:
            speak("Okay")

    global game_mode_active
    game_mode_active = True


def check_unread_emails(username, password):
    '''
        Checks the unread emails in the mail account passed to it
        you can add more mail accounts to the list and to launch them you need to add the path of link properly
    '''

    try:
        # Connect to the Google IMAP server
        mail = imaplib.IMAP4_SSL("imap.gmail.com", 993)

        # Login to the Gmail account
        mail.login(username, password)

        # Select the mailbox to check (e.g., INBOX)
        mail.select("INBOX")

        # Search for unread emails
        _, data = mail.search(None, "UNSEEN")

        # Parse the result
        email_ids = data[0].split()
        num_unread_emails = len(email_ids)

        # Disconnect from the server
        mail.logout()

        return num_unread_emails

    except imaplib.IMAP4.error as e:
        send_output_text(
            "An error occurred while connecting to the mail server:", e)
        return None


def speak_unread_emails():
    '''
        Speaks the unread emails in the mail account passed to it
    '''
    username1 = personal_mail
    password1 = personal_mail_pw

    username2 = secondary_mail
    password2 = secondary_mail_pw

    if username1 == "" or password1 == "":
        speak("You need to add your personal mail and password to use this feature.")
    else:
        num_unread_emails1 = check_unread_emails(username1, password1)
    
    if username2 == "" or password2 == "":
        speak("You need to add your secondary mail and password to use this feature.")
    else:
        num_unread_emails2 = check_unread_emails(username2, password2)

    if num_unread_emails1 is None:
        speak("There is issue with the mail server. Internet connection may be offline.")
    else:
        if num_unread_emails1 == 0:
            speak("You have no unread emails in your personal account.")
        elif num_unread_emails1 == 1:
            speak("You have one unread email in your personal account.")
        else:
            speak(
                f"You have {num_unread_emails1} unread emails in your personal account.")
            if num_unread_emails1 != 0:
                speak("Do you want me to open personal mail?")
                open_mail = try_again()
                if open_mail == True:
                    speak("Opening personal mail")
                    webbrowser.open("https://mail.google.com/mail/u/1/#inbox")
                else:
                    send_output_text("")

    if num_unread_emails2 is None:
        speak("There is issue with the mail server. Internet connection may be offline.")
    else:
        if num_unread_emails2 == 0:
            speak("You have no unread emails in your Secondary account.")
        elif num_unread_emails2 == 1:
            speak("You have one unread email in your Secondary account.")
        else:
            speak(
                f"You have {num_unread_emails2} unread emails in your Secondary account.")
            if num_unread_emails2 != 0:
                speak("Do you want me to open Secondary mail?")
                open_mail = try_again()
                if open_mail == True:
                    speak("Opening Secondary mail")
                    webbrowser.open("https://mail.google.com/mail/u/2/#inbox")
                else:
                    send_output_text("")


def current_time():
    '''
        Speaks the current time
    '''
    current_time = datetime.datetime.now().strftime("%I:%M %p")
    speak(f"The current time is {current_time}")


def handle_note():
    '''
        Handles the notes

    '''
    speak("Do you want to read your notes or write a new one?")
    note_query_audio = listen()
    note_query = recognizer.recognize_google(note_query_audio)
    note_query = note_query.lower()
    if "read" in note_query:
        read_notes()
    elif "write" in note_query or "new" in note_query:
        take_note()
    elif "no" in note_query or "close" in note_query or "exit" in note_query:
        speak("Okay")
        handle_command(listen())
    else:
        speak(
            f"Sorry, I couldn't find any relevant results for '{note_query}'.")
        speak("Do you want me to try again?")
        again = try_again()
        if again == True:
            handle_note()
        else:
            speak("Okay")


def take_note():
    speak("What do you want to write down?")
    audio = listen()
    try:
        notes_query = recognizer.recognize_google(audio)
        notes_query = notes_query.lower()
        current_date = datetime.datetime.now().strftime("%Y-%m-%d")
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        speak("You want to write this down?")
        speak(notes_query)

        note = {
            "date": current_date,
            "time": current_time,
            "note": notes_query
        }

        with open(os.path.join("data", "notes.json"), "r") as file:
            existing_notes = json.load(file)

        existing_notes.append(note)

        # Write all notes back to the file
        with open(os.path.join("data", "notes.json"), "w") as file:
            json.dump(existing_notes, file, indent=4)

        speak("Note saved successfully.")

    except sr.UnknownValueError:
        speak("Sorry, I didn't catch that. Please try again.")
        take_note()


def clear_notes():
    with open(os.path.join("data", "notes.json"), "w") as file:
        json.dump([], file)
    speak("All notes have been removed.")


def read_notes():
    with open(os.path.join("data", "notes.json"), "r") as file:
        notes = json.load(file)
        for note in notes:
            my_note = note["note"]
            date_note = note["date"]
            time = note["time"]
            speak(f"On {date_note} {time}, you wrote:")
            speak(my_note)


def remove_last_note():
    with open(os.path.join("data", "notes.json"), "r") as file:
        notes = json.load(file)

    if len(notes) == 0:
        speak("There are no notes to remove.")
    else:
        removed_note = notes.pop()
        with open(os.path.join("data", "notes.json"), "r") as file:
            json.dump(notes, file, indent=4)
            speak("The last note has been removed.")

        speak("The removed note was:")
        speak(removed_note["note"])


def chatgpt_response(query):
    '''
        Handles the chatgpt response
    '''
    send_output_text("Your Query: ")
    send_output_text(query)
    if "no" in query or "close" in query or "exit" in query or "quit" in query:
        speak("Okay")
        handle_command(listen())
    else:
        content = query
        content = content.lower()
        content = content.replace("athena", "")
        content = content.replace("chatgpt", "")
        completion = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "user", "content": 'You are an assistant named "Athena".'},
                {"role": "user", "content": content}
            ]
        )
        chat_response = completion.choices[0].message.content
        send_output_text(chat_response)
        pyperclip.copy(str(chat_response))
        speak(chat_response)
        handle_command(listen())


def calendar():
    '''
        Reads the calendar events for today and tomorrow events and notifies the user
    '''
    if calendar_link == "":
        speak("You haven't set up your calendar yet. Please set up your calendar first.")
        handle_command(listen())
    else:
        send_output_text("Checking your schedule")
        ics_url = calendar_link
        read_events = get_events(ics_url)

        today = date.today()
        tomorrow = today + timedelta(days=1)

        events_today = []
        events_tomorrow = []

        for event in read_events:
            event_start = event["start"].date()

            if event_start == today:
                events_today.append(event)
            elif event_start == tomorrow:
                events_tomorrow.append(event)

        if events_today:
            speak("You have the following events today:")
            for event in events_today:
                event_start = event["start"].strftime("%I:%M %p")
                event_end = event["end"].strftime("%I:%M %p")
                speak(f"you have classes from {event_start} to {event_end}")
        else:
            speak("No events scheduled for today.")

        if events_tomorrow:
            speak("\nYou have the following events tomorrow:")
            for event in events_tomorrow:
                event_start = event["start"].strftime("%I:%M %p")
                event_end = event["end"].strftime("%I:%M %p")
                speak(f"you have classes from {event_start} to {event_end}")
        else:
            speak("No events scheduled for tomorrow.")


def get_events(ics_url):
    try:
        response = requests.get(ics_url)
        ics_content = response.text

        calendar = Calendar.from_ical(ics_content)
        events = []
        for component in calendar.walk():
            if component.name == "VEVENT":
                event = {
                    "start": component.get("DTSTART").dt,
                    "end": component.get("DTEND").dt,
                }
                events.append(event)

        return events

    except Exception as e:
        print("An error occurred while retrieving events from ICS:", e)
        return None


def say_joke():
    '''
    This function tells a joke to the user
    '''
    speak("Here is a joke for you")
    joke = pyjokes.get_joke()
    send_output_text(joke)
    speak(joke)


def handle_command(audio):
    '''
    This function handles the command given by the user
    '''
    def timeout_func():
        speak("sorry it took took abit long to process your command")
        speak("can you restate your command?")
        handle_command(listen())
    timeout_duration = 10
    timeout = threading.Timer(timeout_duration, timeout_func)
    timeout.start()
    try:
        send_output_text("Processing...")
        command = recognizer.recognize_google(audio)
        command = command.lower()

        timeout.cancel()

        if "introduce" in command or "Athena" in command or "who are you" in command:
            introduce()

        elif "hello" in command or "Hi" in command or "hai" in command:
            greeting()

        elif "youtube" in command or "YouTube" in command:
            speak("Opening Youtube")
            webbrowser.open("https://www.youtube.com/")

        elif "what on my plans today" in command or "open calendar" in command or "calendar" in command or "my classes" in command or "my schedule" in command:
            calendar()

        elif "google" in command or "Google" in command:
            speak("Opening Google")
            webbrowser.open("https://www.google.com/")

        elif "open" in command or "launch" in command:
            open_apps(command)

        elif "i am doing great" in command or "i am fine" in command or " i am happy" in command or " i am good" in command or "i am doing good" in command:
            speak("I am glad to hear that. How can I help you?")

        elif "how are you" in command or "how are you doing" in command or "what about you" in command or "how is it going" in command or "how is your day" in command:
            speak(random.choice(greeting_quotes))
            speak(random.choice(howareyou_quotes))

        elif "meet " in command or "say hi to" in command:
            handle_greeting(command)

        elif "what can you do" in command or "what are your features" in command or "features of you" in command:
            explain_features()

        elif "what is my name" in command or "who am I" in command or "my name" in command:
            speak("Your name is")
            speak(user_name)

        elif "search" in command:
            if check_internet_connection():
                speak("What would you like to search?")
                search_query_audio = listen()
                search_query = recognizer.recognize_google(search_query_audio)
                perform_search(search_query)
            else:
                speak("Sorry, I can't search without an internet connection.")

        elif "thank you" in command or "thanks" in command:
            welcome_quote = ["You're welcome", "No problem",
                             "My pleasure", "It's my duty", "Glad to help", "Anytime"]
            random_welcome = random.choice(welcome_quote)
            speak(random_welcome)

        elif "remind me" in command or "set a reminder" in command or "create note" in command or "create a note" in command or "write a note" in command or "read note" in command or "read notes" in command or "my notes" in command or "make note" in command:
            handle_note()

        elif "remove last note" in command or "remove note" in command or "delete note" in command or "delete last note" in command or "clear all note" in command:
            if "last" in command:
                remove_last_note()
            elif "all" in command:
                clear_notes()
            else:
                speak("Sorry, I didn't catch that")
                handle_command(listen())

        elif "time" in command:
            current_time()

        elif "date" in command:
            today = date.today()
            current_date = today.strftime("%B %d, %Y")
            speak(f"The current date is {current_date}")

        elif "i am sleepy" in command or "bed" in command or "end up here" in command or "goodnight" in command or "Good night" in command or "good night" in command or "goodnight" in command:
            shutdown_pc()

        elif "check email" in command or "email" in command or "mail" in command:
            if check_internet_connection():
                open_email()
            else:
                speak("Sorry, I can't check your email without an internet connection.")

        elif "weather" in command or "temperature" in command or "climate" in command:
            if check_internet_connection():
                check_weather()
            else:
                speak("Sorry, I can't check the weather without an internet connection.")
                speak("I will inform you when the internet connection is back.")

        # if you have spotify installed on your pc, you can uncomment the code below to use it
        # elif "play music" in command or "play  song" in command or "open spotify" in command or "listen to music" in command:
            # speak("Starting a shuffled library of your music")
            # subprocess.Popen("C:\\Users\\ASUS\\AppData\\Roaming\\Spotify\\Spotify.exe")

        elif "bored" in command or "boring" in command or "youtube" in command or "movie" in command or "joke" in command or "jokes" in command:
            speak("I can help you with that.")
            speak("What would you like to do?")
            bored_query_audio = listen()
            bored_query = recognizer.recognize_google(bored_query_audio)
            bored_query = bored_query.lower()
            if "youtube" in bored_query or "site" in bored_query or "movie" in bored_query or "song" in bored_query or "music" in bored_query or "video" in bored_query:
                sites_open()
            elif "game" in bored_query or "play" in bored_query or "valorant" in bored_query or "valor" in bored_query:
                play_games()
            else:
                say_joke()

        elif "code help" in command or "chatgpt" in command or "Help" in command or "help" in command or "gpt" in command:
            if offline_mode:
                speak(
                    "You seem to be offline be patient till you have internet connection.")
            else:
                speak("Please state your query.")
                query = listen()
                query = recognizer.recognize_google(query)
                query = query.lower()
                chatgpt_response(query)

        elif "game mode" in command or "go to sleep" in command or "sleep mode" in command or "run in background" in command or "hibernate" in command:
            game_mode()

        elif "game" in command or "play game" in command:
            if offline_mode:
                speak(
                    "Its not possible right now as you donot have internet connection.")
            else:
                speak("What game would you like to play?")
                game_query_audio = listen()
                game_query = recognizer.recognize_google(game_query_audio)
                game_query = game_query.lower()
                speak("let me check if you have the game installed.")
                if "valorant" in game_query or "valor" in game_query or "valo" in game_query:
                    game_query = "RiotClientServices" or "riot"
                    game_query = game_query.lower()
                    games_data(game_query)

        elif "stop" in command or "see you" in command or "enough for today" in command:
            speak("Hibernating....")
            game_mode()

        elif "sleep" in command:
            speak("I will be running in the background. You can wake me up anytime.")
            speak(random.choice(bye_quotes))
            return False

        elif "athena" in command or "haseena" in command or "athina" in command:
            yes_text = ["Yes", "Umm", "Ahha", "Yes sir"]
            speak(random.choice(yes_text))
        elif "trun off" in command or "quit program" in command or "terminate yourself" in command:
            end()

        elif "minimise" in command or "you are in my way" in command or "you are blocking my view" in command or "you are blocking my screen" in command or "minimize" in command or "go in background" in command or "hide yourself" in command:
            speak("Minimizing...")
            send_maxormin("min")
        elif "normal" in command or "maximise" in command or "come back up" in command or "view you" in command or "maximize" in command or "come back" in command or "come back up" in command:
            speak("Maximizing...")
            send_maxormin("max")
        elif "reboot yourself" in command or "restart yourself" in command or "i have updated you" in command or "update yourself" in command:
            if "reboot" in command or "restart" in command:
                speak("Restarting...")
            else:
                speak("Updating...")
            restart_program()
        elif "anything new" in command or "tell me some facts" in command or "expand my knowledge" in command or "what is " in command or " how " in command or " why " in command or "when" in command or "where" in command or "who" in command or "which" in command or "tell me about" in command or "tell me something about" in command or "tell me" in command or "tell me something" in command:
            if check_internet_connection() and openai_api_key != "":
                speak(
                    "Searching for the answer. If you want to close the conversation, say stop or exit.")
                chatgpt_response(command)
            elif openai_api_key == "":
                speak("Sorry, I can't do that without an OpenAI API key.")
                speak("Please add your OpenAI API key in the user_data.json file.")
            else:
                speak("Sorry, I can't do that without an internet connection.")
                speak("I will inform you when the internet connection is back.")
        else:
            speak("Sorry, I couldn't get that. Can you please say it again?")

    except sr.UnknownValueError:
        send_output_text(
            "Sorry, I am not able to do that. I am still in learning phase. So I am not good at it.")
        speak("Sorry, I am not able to do that. I am still in learning phase. So I am not good at it.")
        handle_command(listen())

    return True


def load_game_data():
    try:
        with open(r'data\game_data.json', 'r') as file:
            game_data = json.load(file)
            return game_data
    except FileNotFoundError:
        return []


def display_game_data(game_data):
    game_names = []
    game_paths = []
    for game in game_data:
        if game != "":
            print("Title:", game['title'])
            game_names.append(game['title'])
            print("File Path:", game['file_path'])
            game_paths.append(game['file_path'])
            print("-" * 30)
        else:
            print("No games found")
    return game_names, game_paths


def games_data(query):
    game_data = load_game_data()
    game_name, game_paths = display_game_data(game_data)
    for game in game_data:
        print(game['title'].lower())
        if query in game['title'].lower():
            game_index = game_name.index(game['title'])
            game_path = game_paths[game_index]
            print(game_path)
            subprocess.Popen(game_path)
            game_mode()
        else:
            continue


def restart_program():
    os.system('cls')
    send_output_text("")
    python = sys.executable
    subprocess.call([python, __file__])
    sys.exit()


def shutdown_pc():
    '''
        This function Shuts down the computer if the user calls the function
    '''
    speak("Do you want to shutdown your computer?")
    send_output_text("Shutdown query listening...")
    shutdown_query_audio = listen()
    shutdown_query = recognizer.recognize_google(shutdown_query_audio)
    shutdown_query = shutdown_query.lower()
    if 'yes' in shutdown_query or "yeah" in shutdown_query or "sure" in shutdown_query:
        speak("Shutting down the computer")
        speak("Before You go, I have a quote for you")
        speak(random.choice(good_night_quotes))
        os.system('shutdown /s /t 0')
    elif 'no' in shutdown_query or "nope" in shutdown_query:
        handle_command(listen())
    else:
        speak(
            f"Sorry, I couldn't find any relevant results for '{shutdown_query}'.")
        speak("Do you want me to try again?")
        again = try_again()
        if again == True:
            return shutdown_pc()
        else:
            return handle_command(listen())


def listen():
    '''
        This function listens for the user input and returns the audio
    '''
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(
            source, duration=1)  # Adjust for ambient noise

        send_output_text("Listening...")
        try:
            # Set the timeout value as desired
            audio = recognizer.listen(source, timeout=5)

        except sr.WaitTimeoutError:
            speak("Are you there?")
            return listen()

    try:
        send_output_text("Recognizing...")
        command = recognizer.recognize_google(audio)
        user_said = "You said:" + command
        send_output_text(user_said)

    except sr.UnknownValueError:
        send_output_text(
            "Sorry, I didn't catch that. Can you please say it again?")
        return listen()

    return audio


def get_last_used_time():
    try:
        with open(r"data\last_used_time.txt", "r") as file:
            last_used_time = float(file.read())
    except FileNotFoundError:
        send_output_text("File not Found")
        last_used_time = 0.0
    return last_used_time


def update_last_used_time():
    send_output_text("Updating the last time used....")
    current_time = time.time()
    with open(r"data\last_used_time.txt", "w") as file:
        file.write(str(current_time))


def calculate_unused_time():
    last_used_time = get_last_used_time()
    current_time = time.time()
    unused_time = current_time - last_used_time
    update_last_used_time()
    return unused_time


def format_time(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)

    days = int(days)
    hours = int(hours)
    minutes = int(minutes)
    seconds = int(seconds)

    send_output_text(
        f"Days: {days}, Hours: {hours}, Minutes: {minutes}, Seconds: {seconds}")
    formatted_time = ""
    if days > 0:
        formatted_time += f"{days} day{'s' if days > 1 else ''} "
    if hours > 0:
        formatted_time += f"{hours} hour{'s' if hours > 1 else ''} "
    if minutes > 0:
        formatted_time += f"{minutes} minute{'s' if minutes > 1 else ''} "
    if formatted_time == "":
        formatted_time = " few moments"

    return formatted_time, hours


def check_last_time():
    '''
        This function checks the last time the program was used and returns True if it has been more than 10 hours which
        says that the user has been away for a long time.
    '''
    unused_time = calculate_unused_time()
    formatted_time, hours = format_time(unused_time)
    if formatted_time == "":
        formatted_time = "Hasn't been long enough"
    send_output_text(formatted_time)
    speak_time = f"It has been {formatted_time}"
    speak(speak_time)

    if hours >= 10:
        speak("Its been long time.")
        return True
    else:
        speak("")
        return False


def set_queue(queue):
    global output_queue
    output_queue = queue


def set_maxormin(value):
    global maxormin
    maxormin = value


def send_maxormin(value):
    if maxormin is not None:
        maxormin.put(value)


def send_output_text(text):
    if output_queue is not None:
        output_queue.put(text)


def check_internet_connection():
    '''
    This function is used to check if the internet connection is available or not.
    '''
    try:
        # Try to establish a connection to a reliable server
        response = requests.get("http://www.google.com", timeout=5)
        return True
    except requests.ConnectionError:
        return False


def time_greet():
    '''
    This function is used to greet the user based on the time of the day.
    '''
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        quote = random.choice(good_morning_quotes)
        speak(quote)
        send_output_text(quote)
    elif hour >= 12 and hour < 18:
        quote = random.choice(good_afternoon_quotes)
        speak(quote)
        send_output_text(quote)
    else:
        quote = random.choice(good_evening_quotes)
        speak(quote)
        send_output_text(quote)


def game_mode():
    '''
    This function is used to run the program in the background and wake it up anytime.
    This is typically used when the user is playing a game and wants to use the program
    without having to minimize the game. or when the user is watching a movie and wants
    to use the program without having to pause the movie.
    '''
    speak("Game mode activated")
    send_output_text("Game mode activated")
    send_maxormin("min")
    speak("I will be running in the background. You can wake me up anytime.")
    speak(random.choice(bye_quotes))
    while True:
        with sr.Microphone() as source:
            try:
                send_output_text("Listening...")
                wait_awake = recognizer.listen(source)
                wait_awake_text = recognizer.recognize_google(
                    wait_awake).lower()
                send_output_text(wait_awake_text)
                if "athena" in wait_awake_text or "help me" in wait_awake_text or "haseena" in wait_awake_text or "system online" in wait_awake_text or "system awake" in wait_awake_text or "wake up" in wait_awake_text or "start up" in wait_awake_text or "hey computer" in wait_awake_text:
                    time_greet()
                    send_maxormin("max")
                    speak(random.choice(awake_quotes))
                    while True:
                        audio_input = listen()
                        if not handle_command(audio_input):
                            break

                elif "stop" in wait_awake_text or "exit" in wait_awake_text:
                    speak("Goodbye!")
                    speak("Have a nice day! You can wake me up anytime.")
                    break

                else:
                    continue

            except sr.UnknownValueError:
                continue


def main():
    '''
        This function is called when the program is run.

        It is the main function of the program.

        It calls all the other functions.

    '''
    time_greet()
    speak(random.choice(awake_quotes))
    check = check_last_time()
    if check == True:
        if check_internet_connection():
            speak(
                "While you were away, let me check if there is any important mail for you.")
            speak_unread_emails()
            while True:
                check_internet_connection()
                audio_input = listen()
                if not handle_command(audio_input):
                    break
        else:
            speak("You are currently offline, so I cant fetch your emails right now. I will try when internet is there.")
            while True:
                audio_input = listen()
                if not handle_command(audio_input):
                    break
    else:
        while True:
            check_internet_connection()
            audio_input = listen()
            if not handle_command(audio_input):
                break


def end():
    '''
        This function is called so that the program is terminated.
    '''
    speak(random.choice(bye_quotes))
    os._exit(0)


# Run the program
if __name__ == "__main__":
    main()
